Imports Microsoft.VisualBasic
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.Data


Public Class dbConection
    Public GivenName As String
    Public connectingString As String
    Public connectingStringOLEDB As String

    Public Function ConnectSql() As SqlConnection
        connectingString = "server=.\SQLEXPRESS;initial catalog=dbTask;uid=sa;pwd=Symon27;Connection Timeout=0;Trusted_Connection=No;" 'Trusted_Connection=No - means using sql authintication
        Dim conn As SqlConnection = New SqlConnection(connectingString)
        Return conn
    End Function

End Class


