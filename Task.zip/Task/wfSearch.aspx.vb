﻿Imports System
Imports System.Data
Imports System.Web
Imports System.IO
Imports System.Data.SqlClient

Partial Class wfSearch
    Inherits System.Web.UI.Page
    Dim db As dbConection = New dbConection()
    Dim conn As SqlConnection = db.ConnectSql()

    Protected Sub btnSearch_Click(sender As Object, e As System.EventArgs) Handles btnSearch.Click
        Try
            lblMsg.Text = ""
            'LOAD Task
            Dim dt As New DataTable
            Dim dr As DataRow
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()
            Dim sql As String = "SELECT * FROM tbTask WHERE TaskID>0"
            If Len("" & txtTaskID.Text.Trim) > 0 Then
                sql = sql & " AND TaskID=" & txtTaskID.Text & ""
            End If
            If Len("" & ddlStatus.SelectedItem.Text) > 0 Then
                Dim stus As Integer = 0
                If "" & ddlStatus.SelectedItem.Text = "Done" Then stus = 1
                sql = sql & " AND Status=" & stus & ""
            End If
            sql = sql & " ORDER BY TaskID DESC"
            Dim cmd As SqlCommand = New SqlCommand(sql, conn)
            Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(ds)
            For j = 0 To ds.Tables(0).Rows.Count - 1
                dr = dt.NewRow()
                dt.Rows.Add(dr)
            Next
            Dim dv As New DataView(dt)
            dgVT.DataSource = dv
            dgVT.DataBind()

            For j = 0 To ds.Tables(0).Rows.Count - 1
                CType(dgVT.Items(j).FindControl("lblSL"), Label).Text = j + 1
                CType(dgVT.Items(j).FindControl("lblTaskID"), Label).Text = "" & ds.Tables(0).Rows(j).Item("TaskID")
                CType(dgVT.Items(j).FindControl("lblTaskTitle"), Label).Text = "" & ds.Tables(0).Rows(j).Item("Title")
                CType(dgVT.Items(j).FindControl("lblDescription"), Label).Text = "" & ds.Tables(0).Rows(j).Item("Description")
                CType(dgVT.Items(j).FindControl("lblStatus"), Label).Text = IIf("" & ds.Tables(0).Rows(j).Item("Status") = True, "Done", "Undone")
                CType(dgVT.Items(j).FindControl("lblDDt"), Label).Text = "" & ds.Tables(0).Rows(j).Item("DueDateTime")
            Next
            If conn.State = ConnectionState.Open Then conn.Close()
        Catch ex As Exception
            lblMsg.Text = Err.Description
        End Try
    End Sub
End Class
