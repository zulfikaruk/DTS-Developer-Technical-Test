﻿Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            txtEmail.Text = "info@abcltd.com"
            txtUserID.Text = "Admin"
            txtPassword.Attributes("value") = "12345"
            chkTick.Checked = True
        End If

    End Sub


    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        msg.Text = "SIGN IN"
        If chkTick.Checked = True Then
            Response.Redirect("wfTask.aspx")
        Else
            msg.Text = "please tick the check box !!!"
        End If
    End Sub
End Class
