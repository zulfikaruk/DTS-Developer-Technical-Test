﻿Imports System
Imports System.Data
Imports System.Web
Imports System.IO
Imports System.Data.SqlClient

Partial Class wfTask
    Inherits System.Web.UI.Page
    Dim db As dbConection = New dbConection()
    Dim conn As SqlConnection = db.ConnectSql()

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            Session("Refresh") = Server.UrlEncode(System.DateTime.Now.ToString()) 'page refresh state
            'Set the current datetime as default value
            txtDueDate.Text = DateTime.Now.ToString("yyyy-MM-ddTHH:mm")
            fnViewTask()
        End If
    End Sub

    Protected Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
        ViewState("Refresh") = Session("Refresh")
    End Sub

    Protected Sub btnSave_Click(sender As Object, e As System.EventArgs) Handles btnSave.Click
        fnSaveUpdate("Save")
    End Sub

    Protected Sub btnUpdate_Click(sender As Object, e As System.EventArgs) Handles btnUpdate.Click
        fnSaveUpdate("Update")
    End Sub

    Private Sub fnSaveUpdate(ByVal saveup As String)
        Try
            lblMsg.Text = ""
            If Len(txtTitle.Text.Trim) = 0 Then
                lblMsg.Text = "Please enter task title"
                Exit Sub
            ElseIf Len(ddlStatus.SelectedItem.Text) = 0 Then
                lblMsg.Text = "Please select task status"
                Exit Sub
            ElseIf Len(txtDueDate.Text) = 0 Then
                lblMsg.Text = "Please enter due date and time"
                Exit Sub
            Else
                If Session("Refresh").ToString = ViewState("Refresh").ToString Then
                    If conn.State = ConnectionState.Open Then conn.Close()
                    conn.Open()
                    'SAVE TASK
                    Dim DDt As Date = txtDueDate.Text
                    Dim sql As String = ""
                    If saveup = "Update" Then
                        sql = "UPDATE tbTask SET Title='" & txtTitle.Text & "',Description='" & "" & txtDescription.Text & "',Status=" & ddlStatus.SelectedValue & ",DueDateTime='" & DDt & "'"
                        sql = sql & " WHERE TaskID=" & txtTitle.ToolTip & ""
                        lblMsg.Text = "Data Successfully Updated"
                    ElseIf saveup = "Save" Then
                        sql = "INSERT INTO tbTask(Title,Description,Status,DueDateTime) "
                        sql = sql & " VALUES('" & txtTitle.Text & "','" & "" & txtDescription.Text & "'," & ddlStatus.SelectedValue & ",'" & DDt & "')"
                        lblMsg.Text = "Data Successfully Saved"
                    End If

                    Dim cmd As SqlCommand = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    'INITIALISE
                    btnSave.Visible = True
                    btnUpdate.Visible = False
                    txtTitle.Text = ""
                    txtDescription.Text = ""
                    ddlStatus.SelectedIndex = 0
                    txtTitle.ToolTip = 0
                    txtDueDate.Text = DateTime.Now.ToString("yyyy-MM-ddTHH:mm")
                    Session("Refresh") = Server.UrlEncode(System.DateTime.Now.ToString())
                    If conn.State = ConnectionState.Open Then conn.Close()
                    fnViewTask()
                End If
            End If
        Catch ex As Exception
            lblMsg.Text = Err.Description
        End Try
    End Sub

    Private Sub fnViewTask()
        Try
            lblMsg.Text = ""
            'LOAD Task
            Dim dt As New DataTable
            Dim dr As DataRow
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()
            Dim sql As String = "SELECT * FROM tbTask ORDER BY TaskID DESC"
            Dim cmd As SqlCommand = New SqlCommand(sql, conn)
            Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(ds)
            For j = 0 To ds.Tables(0).Rows.Count - 1
                dr = dt.NewRow()
                dt.Rows.Add(dr)
            Next
            Dim dv As New DataView(dt)
            dgVT.DataSource = dv
            dgVT.DataBind()

            For j = 0 To ds.Tables(0).Rows.Count - 1
                CType(dgVT.Items(j).FindControl("lblSL"), Label).Text = j + 1
                CType(dgVT.Items(j).FindControl("lblTaskID"), Label).Text = "" & ds.Tables(0).Rows(j).Item("TaskID")
                CType(dgVT.Items(j).FindControl("lblTaskTitle"), Label).Text = "" & ds.Tables(0).Rows(j).Item("Title")
                CType(dgVT.Items(j).FindControl("lblDescription"), Label).Text = "" & ds.Tables(0).Rows(j).Item("Description")
                CType(dgVT.Items(j).FindControl("lblStatus"), Label).Text = IIf("" & ds.Tables(0).Rows(j).Item("Status") = True, "Done", "Undone")
                CType(dgVT.Items(j).FindControl("lblDDt"), Label).Text = "" & ds.Tables(0).Rows(j).Item("DueDateTime")
            Next
            If conn.State = ConnectionState.Open Then conn.Close()
        Catch ex As Exception
            lblMsg.Text = Err.Description
        End Try
    End Sub

    Protected Sub dgVT_ItemCommand(source As Object, e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgVT.ItemCommand
        Try
            lblMsg.Text = ""
            Dim index As Integer = Convert.ToInt32(e.CommandArgument)
            If (e.CommandName = "Edit") Then
                txtTitle.ToolTip = "" & CType(dgVT.Items(index).FindControl("lblTaskID"), Label).Text
                txtTitle.Text = "" & CType(dgVT.Items(index).FindControl("lblTaskTitle"), Label).Text
                txtDescription.Text = "" & CType(dgVT.Items(index).FindControl("lblDescription"), Label).Text
                ddlStatus.SelectedValue = IIf(UCase("" & CType(dgVT.Items(index).FindControl("lblStatus"), Label).Text) = "DONE", 1, 0)
                Dim DDt As Date = "" & CType(dgVT.Items(index).FindControl("lblDDt"), Label).Text
                txtDueDate.Text = Format(DDt, "yyyy-MM-dd HH:mm")
                btnSave.Visible = False
                btnUpdate.Visible = True
            ElseIf (e.CommandName = "Delete") Then
                If conn.State = ConnectionState.Open Then conn.Close()
                conn.Open()
                Dim cmd As SqlCommand = New SqlCommand("DELETE FROM tbTask WHERE TaskID=" & CType(dgVT.Items(index).FindControl("lblTaskID"), Label).Text & "", conn)
                cmd.ExecuteNonQuery()
                If conn.State = ConnectionState.Open Then conn.Close()
                fnViewTask()
                lblMsg.Text = "Date Successfully Deleted"
            End If
        Catch ex As Exception
            lblMsg.Text = Err.Description
        End Try
    End Sub
End Class
